package main

/*
import "testing"

var (
	inputfiles := []string{
		// "input_test.txt",
		// "input.txt",
	}
)

func TestSol(t *testing.T) {
}

func BenchmarkSol(1 *testing.B) {
	for i := 0; i < b.N; i++ {
		sol1("input_test.txt")
	}

	for idx, inputfile := range inputfiles {
		utl.Debug(debuglvl >= 1, "File \t\t: %d %s\n", idx+1, inputfile)
		a := NewAoc()
		a.parsefile(inputfile)

		name := strconv.Itoa(idx) + ": " + inputfile
		a.runSolutions(name)
	}
}

func TestSol2(t *testing.T) {
	ans := sol2(test)
	if ans != -1 {
		t.Errorf("Sol1_1 =%d ;want XXX", ans)
	}
}

func BenchmarkSol2(b *testing.B) {
	for i := 0; i < b.N; i++ {
		sol2(test)
	}
}
*/
