package main

import "fmt"

// day 3 data
type cor struct {
	x int
	y int
}

// var p map[cor]int

func main() {
	var c cor
	c.x = 0
	c.y = 1
	note := make(map[cor]int)
	
	note[c] = 69
	
	note[{1,1}] = 169
	
	fmt.Println(note)
}
