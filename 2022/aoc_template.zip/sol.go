package main

import (
	"bufio"
	"log"
	"os"

	"github.com/davidn5013/aoc/utl"
)

// Aoc is a place for the main datastruct in this solution
type Aoc struct {
}

// NewAoc Aoc struct for cpu information
func NewAoc() *Aoc {
	a := Aoc{}
	return &a
}

func (a *Aoc) parse(filename string) {
	startmsg(utl.CurrFuncName())

	fp, err := os.Open(filename)
	if err != nil {
		log.Fatal(err)
	}
	defer func() {
		err := fp.Close()
		if err != nil {
			log.Fatal(err)
		}
	}()
	sc := bufio.NewScanner(fp)

	for sc.Scan() {
		// fmt.Sscanf(sc.Text(), "%s %d", &, &)
		// a. = append(a.,)
	}

}

func (a *Aoc) sol1() (ret int) {
	startmsg(utl.CurrFuncName())
	return ret
}

func (a *Aoc) sol2() (ret int) {
	startmsg(utl.CurrFuncName())
	return ret
}
